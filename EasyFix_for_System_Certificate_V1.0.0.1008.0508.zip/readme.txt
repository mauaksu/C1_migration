EasyFix for System Certificates
version 1.0.0.1006, released 12/13/2022
Copyright (c) 2022 Trend Micro, Inc.


Abstract
--------

EasyFix for System Certificates inspects the operating system to identify the missing certificate(s)
required by Trend Micro Apex One 2019, Trend Micro Apex One SaaS ，Trend Micro Cloud One Workload Security Agentor Trend Micro Vision One Agent.
The tool imports those certificate(s) to the operating system automatically. And the result of certificate
inspection and recovery is recorded in a log file.

The certificates required by Trend Micro Apex One 2019 and Trend Micro Apex One SaaS.
	Root certificates:
		DigiCert Assured ID Root CA (thumbprint: 0563B8630D62D75ABBC8AB1E4BDFB5A899B24D43)
		DigiCert High Assurance EV Root CA (thumbprint: 5FB7EE0633E259DBAD0C4C9AE6D38F1A61C7DC25)
		VeriSign Class 3 Public Primary Certification Authority - G5 (thumbprint: 4EB6D578499B1CCF5F581EAD56BE3D9B6744A5E5)
		VeriSign Universal Root Certification Authority (thumbprint: 3679CA35668772304D30A5FB873B0FA77BB70D54)
		DigiCert Trusted Root G4 (thumbprint: ddfb16cd4931c973a2037d3fc83a4d7d775d05e4)
		USERTrust RSA Certification Authority (thumbprint: 2b8f1b57330dbba2d07a6c51f70ee90ddab9ad8e)
		Microsoft Identity Verification Root Certificate Authority 2020(thumbprint: F40042E2E5F7E8EF8189FED15519AECE42C3BFA2)
		thawte Primary Root CA(thumbprint: 91c6d6ee3e8ac86384e548c299295c756c817b81)
		GlobalSign(thumbprint: d69b561148f01c77c54578c10926df5b856976ad)
		Microsoft Root Certificate Authority 2010 (thumbprint: 3B1EFD3A66EA28B16697394703A72CA340A05BD5)
		Microsoft Root Certificate Authority 2011 (thumbprint: 8F43288AD272F3103B6FB1428485EA3014C0BCFE)
		Microsoft Root Authority (thumbprint: a43489159a520f0d93d032ccaf37e7fe20a8b419)
		Thawte Timestamping CA (thumbprint: E36A4562FB2EE05DBB3D32323ADF445084ED656)
		UTN-USERFirst-Object(thumbprint: e12dfb4b41d7d9c32b30514bac1d81d8385e2d46)
		AddTrust External CA Root(thumbprint: 02FAF3E291435468607857694DF5E45B68851868)
		
		

	Intermediate certificates:
		DigiCert EV Code Signing CA (SHA2) (thumbprint: 60ee3fc53d4bdfd1697ae5beae1cab1c0f3ad4e3)
		DigiCert EV Code Signing CA (thumbprint: 846896ab1bcf45734855c61b63634dfd8719625b)
		DigiCert High Assurance Code Signing CA-1 (thumbprint: e308f829dc77e80af15edd4151ea47c59399ab46)
		Symantec Class 3 SHA256 Code Signing CA (thumbprint: 007790f6561dad89b0bcd85585762495e358f8a5)
		DigiCert Trusted G4 Code Signing RSA4096 SHA384 2021 CA1 (thumbprint: 7b0f360b775f76c94a12ca48445aa2d2a875701c)
		
The certificates required by Trend Micro Vision One Agent.
	Root certificates:
		Entrust Root Certification Authority - G2(thumbprint: 8cf427fd790c3ad166068de81e57efbb932272d4)
		DigiCert Assured ID Root CA (thumbprint: 0563B8630D62D75ABBC8AB1E4BDFB5A899B24D43)
		DigiCert Trusted Root G4 (thumbprint: ddfb16cd4931c973a2037d3fc83a4d7d775d05e4)
		USERTrust RSA Certification Authority (thumbprint: 2b8f1b57330dbba2d07a6c51f70ee90ddab9ad8e)		
		Amazon Root CA 1 (thumbprint: 8da7f965ec5efc37910f1c6e59fdc1cc6a6ede16)

	Intermediate certificates:
		Entrust Certification Authority - L1K(thumbprint: F21C12F46CDB6B2E16F09F9419CDFF328437B2D7)
		
The certificates required by Trend Micro Cloud One Workload Security Agent.
	Root certificates:
		DigiCert Assured ID Root CA (thumbprint: 0563B8630D62D75ABBC8AB1E4BDFB5A899B24D43)
		DigiCert Global Root CA (thumbprint: A8985D3A65E5E5C4B2D7D66D40C6DD2FB19C5436)
		DigiCert Global Root G2  (thumbprint: DF3C24F9BFD666761B268073FE06D1CC8D4F82A4)
		DigiCert High Assurance EV Root CA  (thumbprint: 5FB7EE0633E259DBAD0C4C9AE6D38F1A61C7DC25)
		DigiCert Trusted Root G4 (thumbprint: DDFB16CD4931C973A2037D3FC83A4D7D775D05E4)
		USERTrust RSA Certification Authority (thumbprint: 2B8F1B57330DBBA2D07A6C51F70EE90DDAB9AD8E)
		VeriSign Class 3 Public Primary Certification Authority - G5 (thumbprint: 4EB6D578499B1CCF5F581EAD56BE3D9B6744A5E5)
		VeriSign Universal Root Certification Authority (thumbprint: 3679CA35668772304D30A5FB873B0FA77BB70D54)
		Microsoft Root Certificate Authority 2010 (thumbprint: 3B1EFD3A66EA28B16697394703A72CA340A05BD5)
		Microsoft Root Certificate Authority 2011 (thumbprint: 8F43288AD272F3103B6FB1428485EA3014C0BCFE)
		Microsoft Root Certificate Authority (thumbprint:  CDD4EEAE6000AC7F40C3802C171E30148030C072)
		Thawte Timestamping CA (thumbprint:  BE36A4562FB2EE05DBB3D32323ADF445084ED656)
		Microsoft Identity Verification Root Certificate Authority 2020(thumbprint: F40042E2E5F7E8EF8189FED15519AECE42C3BFA2)



Requirements
------------

This tool can be executed on any Windows platform supported by the installed product.
A product license of following products are required for using this tool.
	- Trend Micro Apex One 2019
	- Trend Micro Apex One SaaS
	- Trend Micro Vision One Agent
	- Trend Micro Cloud One Workload Security Agent.

Installation
------------

This tool can be deployed via a software distribution platform to massive Windows machines.
And it can also be executed manually by following below steps:
	1. Extract all files from "EasyFix_for_System_Certificates_v1.0.zip" to a temp folder, e.g. C:\temp.
	2. Go to the temp folder C:\temp and execute EasyFixSysCerts.exe in CMD with administrator privilege. 
	- To inspect and import missing certificates for Trend Micro Apex One 2019 and Trend Micro Apex One SaaS
		EasyFixSysCerts.exe A1
	- To inspect and import missing certificates for Trend Micro Vision One Agent
		EasyFixSysCerts.exe V1
	- To inspect and import missing certificates for Trend Micro Cloud One Workload Security Agent
		EasyFixSysCerts.exe C1
	3. The tool executes in silent mode. Check the tool log file "C:\temp\Log\EasyFixSysCerts.log" to confirm the execution result.
	Search the flowing key words to confirm the execution result: 
	- Fixing result is True
	- Fixing result is False


History
-------

02/08/2021	v1.0.0.1000	Official release
02/19/2021	v1.0.0.1001	Official release. Enhance the tool to inspects intermediate certificates.
01/20/2022	v1.0.0.1002	Official release. Add new certificates (DigiCert Trusted Root G4, USERTrust RSA Certification Authority). Remove expired certificates (Thawte Timestamping CA, AddTrust External CA Root).
03/15/2022	v1.0.0.1003	Official release. Add supports for Trend Micro Vision One Agent.
04/20/2022	v1.0.0.1004	Official release. Add supports for Trend Micro Cloud One Workload Security Agent.
07/29/2022	v1.0.0.1005	Official release. Add new certificates(Microsoft Identity Verification Root Certificate Authority 2020),Remove Intermediate certificates of Trend Micro Cloud One Workload Security Agent.
10/28/2022	v1.0.0.1006	Official release. Add new certificates(thawte Primary Root CA,GlobalSign).
12/22/2022	v1.0.0.1007	Official release. Add new certificates(Amazon Root CA 1).
05/08/2023	v1.0.0.1008	Official release. Add new certificates(Thawte Timestamping CA, AddTrust External CA Root,Microsoft Root Certificate Authority 2011,Microsoft Root Certificate Authority 2010,Microsoft Root Authority,UTN-USERFirst-Object) for Trend Micro Apex One 2019 and Trend Micro Apex One SaaS.